const pool = require('../config/database');

const obtenerCategorias = async (req, res) => {
  try {
    const [categorias] = await pool.query('SELECT * FROM categorias');
    res.json(categorias);
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error al obtener categorías' });
  }
};

const obtenerCategoria = async (req, res) => {
  try {
    const { id } = req.params;
    const [categoria] = await pool.query('SELECT * FROM categorias WHERE id = ?', [id]);
    if (categoria.length === 0) {
      return res.status(404).json({ mensaje: 'Categoría no encontrada' });
    }
    res.json(categoria[0]);
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error al obtener la categoría' });
  }
};

const crearCategoria = async (req, res) => {
  try {
    const { nombre, descripcion } = req.body;
    const [resultado] = await pool.query(
      'INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)',
      [nombre, descripcion]
    );
    res.status(201).json({
      ok: true,
      mensaje: 'Categoría creada con éxito',
      id: resultado.insertId
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error en el servidor' });
  }
};

const actualizarCategoria = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, descripcion } = req.body;
    await pool.query(
      'UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?',
      [nombre, descripcion, id]
    );
    res.json({ ok: true, mensaje: 'Categoría actualizada con éxito' });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error en el servidor' });
  }
};

const eliminarCategoria = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM categorias WHERE id = ?', [id]);
    res.json({ ok: true, mensaje: 'Categoría eliminada con éxito' });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error en el servidor' });
  }
};

module.exports = {
  obtenerCategorias,
  obtenerCategoria,
  crearCategoria,
  actualizarCategoria,
  eliminarCategoria
};