const pool = require('../config/database');
 
  // ✅ 1. Lista todos los productos con nombre de categoría
const obtenerProductos = async (req, res) => {
  try {
    const [productos] = await pool.query(`
      SELECT 
        p.id,
        p.nombre,
        p.descripcion,
        p.precio,
        p.stock,
        p.categoria_id,
        c.nombre AS categoria_nombre,
        p.estado,
        p.created_at
      FROM productos p
      LEFT JOIN categorias c ON p.categoria_id = c.id
      WHERE p.estado = 1
      ORDER BY p.id DESC
    `);
    res.json({ ok: true, productos });
  } catch (error) {
    console.log(error);
    res.status(500).json({ ok: false, mensaje: 'Error al obtener productos' });
  }
};

// ✅ 2. Obtener un solo producto por ID
const obtenerProducto = async (req, res) => {
  try {
    const { id } = req.params;
    const [producto] = await pool.query("SELECT * FROM productos WHERE id = ?", [id]);
    if (producto.length === 0) {
      return res.status(404).json({ ok: false, mensaje: 'Producto no encontrado' });
    }
    res.json({ ok: true, producto: producto[0] });
  } catch (error) {
    console.log(error);
    res.status(500).json({ ok: false, mensaje: 'Error al obtener producto' });
  }
};
const crearProducto = async (req, res) => {
  try {
    const { nombre, descripcion, precio, categoria_id, stock, estado } = req.body;
    const [resultado] = await pool.query(
      'INSERT INTO productos (nombre, descripcion, precio, categoria_id, stock, estado) VALUES (?, ?, ?, ?, ?, ?)',
      [nombre, descripcion, precio, categoria_id, stock, estado]
    );
    res.status(201).json({ ok: true, mensaje: 'Producto creado con éxito', id: resultado.insertId });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error en el servidor' });
  }
};

const actualizarProducto = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, descripcion, precio, categoria_id, stock, estado } = req.body;
    await pool.query(
      'UPDATE productos SET nombre = ?, descripcion = ?, precio = ?, categoria_id = ?, stock = ?, estado = ? WHERE id = ?',
      [nombre, descripcion, precio, categoria_id, stock, estado, id]
    );
    res.json({ ok: true, mensaje: 'Producto actualizado con éxito' });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error en el servidor' });
  }
};

const eliminarProducto = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM productos WHERE id = ?', [id]);
    res.json({ ok: true, mensaje: 'Producto eliminado con éxito' });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error en el servidor' });
  }
};

module.exports = {
  obtenerProductos,
  obtenerProducto,
  crearProducto,
  actualizarProducto,
  eliminarProducto
};