const pool = require('../config/database');

// Obtener todas las ventas
const obtenerVentas = async (req, res) => {
  try {
    const [ventas] = await pool.query(`
      SELECT v.*, u.nombre as usuario_nombre 
      FROM ventas v 
      LEFT JOIN usuarios u ON v.usuario_id = u.id 
      ORDER BY v.fecha DESC
    `);
    res.json(ventas);
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error al obtener las ventas' });
  }
};

// Obtener una venta por ID
const obtenerVenta = async (req, res) => {
  try {
    const { id } = req.params;
    const [venta] = await pool.query(`
      SELECT v.*, u.nombre as usuario_nombre 
      FROM ventas v 
      LEFT JOIN usuarios u ON v.usuario_id = u.id 
      WHERE v.id = ?
    `, [id]);
    
    if (venta.length === 0) {
      return res.status(404).json({ mensaje: 'Venta no encontrada' });
    }
    
    // Obtener los detalles de la venta
    const [detalles] = await pool.query(`
      SELECT dv.*, p.nombre as producto_nombre 
      FROM detalle_ventas dv 
      LEFT JOIN productos p ON dv.producto_id = p.id 
      WHERE dv.venta_id = ?
    `, [id]);
    
    res.json({
      ...venta[0],
      detalles: detalles
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error al obtener la venta' });
  }
};

// Crear nueva venta
const crearVenta = async (req, res) => {
  const connection = await pool.getConnection();
  
  try {
    await connection.beginTransaction(); // Iniciar transacción
    
    const { usuario_id, productos, total } = req.body;
    
    // 1. Crear la venta
    const [ventaResult] = await connection.query(
      'INSERT INTO ventas (usuario_id, fecha, total) VALUES (?, NOW(), ?)',
      [usuario_id, total]
    );
    
    const ventaId = ventaResult.insertId;
    
    // 2. Insertar cada producto en detalle_ventas
    for (const item of productos) {
      await connection.query(
        'INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)',
        [ventaId, item.producto_id, item.cantidad, item.precio_unitario, item.subtotal]
      );
      
      // 3. Descontar del stock
      await connection.query(
        'UPDATE productos SET stock = stock - ? WHERE id = ?',
        [item.cantidad, item.producto_id]
      );
    }
    
    await connection.commit(); // Confirmar todo
    
    res.status(201).json({
      ok: true,
      mensaje: 'Venta registrada con éxito',
      venta_id: ventaId
    });
  } catch (error) {
    await connection.rollback(); // Deshacer si hay error
    console.log(error);
    res.status(500).json({ mensaje: 'Error al registrar la venta' });
  } finally {
    connection.release();
  }
};

// Eliminar venta
const eliminarVenta = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM detalle_ventas WHERE venta_id = ?', [id]);
    await pool.query('DELETE FROM ventas WHERE id = ?', [id]);
    res.json({ ok: true, mensaje: 'Venta eliminada con éxito' });
  } catch (error) {
    console.log(error);
    res.status(500).json({ mensaje: 'Error al eliminar la venta' });
  }
};

module.exports = {
  obtenerVentas,
  obtenerVenta,
  crearVenta,
  eliminarVenta
};