const pool = require('../config/database');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// 📝 Registrar un usuario nuevo
const registro = async (req, res) => {
  try {
    const { nombre, correo, telefono, direccion, rol, password } = req.body;

    // ✅ Verificar que los datos obligatorios lleguen
    if (!nombre || !correo || !password) {
      return res.status(400).json({ 
        mensaje: '⚠️ Nombre, correo y contraseña son obligatorios' 
      });
    }

    // 🔍 Revisar si el correo ya está registrado
    const [usuarioExiste] = await pool.query(
      'SELECT id FROM usuarios WHERE correo = ?',
      [correo]
    );
    if (usuarioExiste.length > 0) {
      return res.status(400).json({ mensaje: '⚠️ Este correo ya está registrado' });
    }

    // 🔒 Encriptar la contraseña (nadie la ve, ni tú)
    const passEncriptado = await bcrypt.hash(password, 10);

    // 💾 Guardar en la base de datos
    const [resultado] = await pool.query(
      `INSERT INTO usuarios (nombre, correo, telefono, direccion, rol, password) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [nombre, correo, telefono || '', direccion || '', rol || 'mesero', passEncriptado]
    );

    // ✅ Responder que todo salió bien
    res.status(201).json({
      mensaje: '✅ Usuario registrado con éxito',
      id: resultado.insertId
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: '❌ Error en el servidor' });
  }
};

// 📝 Iniciar sesión
const login = async (req, res) => {
  try {
    const { correo, password } = req.body;

    // ✅ Verificar que lleguen los datos
    if (!correo || !password) {
      return res.status(400).json({ 
        mensaje: '⚠️ Correo y contraseña son obligatorios' 
      });
    }

    // 🔍 Buscar al usuario en la base de datos
    const [usuarios] = await pool.query(
      'SELECT * FROM usuarios WHERE correo = ? AND estado = 1',
      [correo]
    );
    if (usuarios.length === 0) {
      return res.status(401).json({ mensaje: '❌ Correo o contraseña incorrectos' });
    }

    const usuario = usuarios[0];

    // 🔓 Comparar contraseña ingresada con la guardada
    const contraseñaCorrecta = await bcrypt.compare(password, usuario.password);
    if (!contraseñaCorrecta) {
      return res.status(401).json({ mensaje: '❌ Correo o contraseña incorrectos' });
    }

    // 🎫 Crear el token = "llave de acceso por 24 horas"
    const claveSecreta = process.env.JWT_CLAVE;
    const token = jwt.sign(
      { id: usuario.id, correo: usuario.correo, rol: usuario.rol },
      claveSecreta,
      { expiresIn: '24h' }
    );

    // ✅ Responder con el token y los datos del usuario
    res.json({
      mensaje: '✅ ¡Bienvenido! Sesión iniciada',
      token,
      usuario: {
        id: usuario.id,
        nombre: usuario.nombre,
        correo: usuario.correo,
        rol: usuario.rol
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: '❌ Error en el servidor' });
  }
};
// Mostrar en el perfil del usuario que ha iniciado sección

const perfil = async (req, res) => {
  try {
  res.json({
    mensaje:"Estos son tus datos de perfil",
    usuario: req.usuario
  });
  } catch (error) { 
    res.status (500).json ({ mensaje: "❌ Error al cargar perfil"});
 }
 };
// Actualizar datos del usuario
const actualizar = async (req, res) => {
  try {
    const { nombre, telefono, direccion, correo } = req.body;
    const usuarioId = req.usuario.id;

    if (!nombre && !telefono && !direccion && !correo) {
      return res.status(400).json({
        mensaje: 'Debes enviar al menos un campo para actualizar'
      });
    }

    const campos = [];
    const valores = [];

    if (nombre) { campos.push('nombre = ?'); valores.push(nombre); }
    if (telefono) { campos.push('telefono = ?'); valores.push(telefono); }
    if (direccion) { campos.push('direccion = ?'); valores.push(direccion); }
    if (correo) { campos.push('correo = ?'); valores.push(correo); }


    valores.push(usuarioId);

    const consulta = `UPDATE usuarios SET ${campos.join(', ')} WHERE id = ?`;
    
    await pool.query(consulta, valores);

    // Consultar el usuario actualizado
    const [usuarioActualizado] = await pool.query(
      'SELECT id, nombre, correo, telefono, direccion, rol FROM usuarios WHERE id = ?',
      [usuarioId]
    );

    res.json({
      mensaje: '✅ Usuario actualizado correctamente',
      usuario: usuarioActualizado[0]
    });

  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      mensaje: '❌ Error al actualizar el usuario'
    });
  }
};




module.exports = { registro, login, perfil, actualizar};