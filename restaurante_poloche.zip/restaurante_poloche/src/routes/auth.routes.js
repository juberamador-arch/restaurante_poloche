const express = require('express');
const router = express.Router();
const { registro, login, perfil, actualizar } = require('../controllers/auth.controller');
const { verificarToken } = require('../middleware/auth.middleware');

router.post('/registro', registro);
router.post('/login', login);
router.get('/perfil', verificarToken, perfil);
router.put('/actualizar', verificarToken, actualizar);

module.exports = router;
