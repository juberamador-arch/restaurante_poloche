const express = require('express');
const {  
  obtenerVentas,
  obtenerVenta,
  crearVenta,
eliminarVenta
} = require('../controllers/ventas.controller');

const router = express.Router();


router.get('/', obtenerVentas);
router.get('/:id', obtenerVenta);
router.post('/', crearVenta);
router.delete('/:id', eliminarVenta);

module.exports = router;