// Importar herramientas
require('dotenv').config();
const express = require('express');
const cors = require('cors');

// Crear el servidor
const app = express();
const PUERTO = process.env.PUERTO || 3000;

// Configuración básica
app.use(cors()); // Permite que otras apps se conecten
app.use(express.json()); // El servidor entiende información en formato JSON
app.use(express.urlencoded({ extended:true}));

// Importar rutas
const authRoutes = require('./routes/auth.routes');
const productosRoutes = require('./routes/productos.routes');
const categoriasRoutes = require('./routes/categorias.routes');
const ventasRoutes = require('./routes/ventas.routes');
// Usar rutas
app.use('/api/auth', authRoutes);
app.use('/api/productos', productosRoutes);
app.use('/api/categorias', categoriasRoutes);
app.use('/api/ventas', ventasRoutes);
// Ruta de prueba
app.get('/', (req, res) => {
  res.send('Servidor de Restaurante Poloche funcionando correctamente! ✅');
});

// Iniciar el servidor
app.listen(PUERTO, () => {
  console.log(`✅ Servidor corriendo en: http://localhost:${PUERTO}`);
});