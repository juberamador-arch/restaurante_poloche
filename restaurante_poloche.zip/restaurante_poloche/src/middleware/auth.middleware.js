const jwt = require('jsonwebtoken');

// 🛡️ Función que revisa si tienes permiso de entrar
const verificarToken = (req, res, next) => {
  try {
    // 1. Recibir el token desde la petición
    const authHeader = req.headers['authorization'];
    
    if (!authHeader) {
      return res.status(401).json({ mensaje: '⚠️ No tienes permiso. Inicia sesión.' });
    }

    // 2. Extraer solo el token (quitar la palabra "Bearer ")
    const token = authHeader.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ mensaje: '⚠️ Token inválido' });
    }

    // 3. Verificar que el token sea correcto
    const claveSecreta = process.env.JWT_CLAVE;
    const datosUsuario = jwt.verify(token, claveSecreta);

    // 4. Si todo está bien, guardar los datos del usuario y continuar
    req.usuario = datosUsuario;
    next(); // ✅ ¡Puedes pasar!
  } catch (error) {
    console.error(error);
    return res.status(403).json({ mensaje: '❌ Token incorrecto o expirado' });
  }
};

module.exports = { verificarToken };